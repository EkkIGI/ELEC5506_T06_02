var searchData=
[
  ['calculatechecksum_0',['calculateChecksum',['../_interlock___code___f_o_r_d_o_x_y_8c.html#a8c2694355e28158a1d9c492fd7267a93',1,'calculateChecksum(const byte *Frame, size_t FrameLength):&#160;Interlock_Code_FORDOXY.c'],['../_r_s232___luke___final__rev1___f_o_r_d_o_x_y_8c.html#a8c2694355e28158a1d9c492fd7267a93',1,'calculateChecksum(const byte *Frame, size_t FrameLength):&#160;RS232_Luke_Final_rev1_FORDOXY.c']]],
  ['colpins_1',['colPins',['../_interlock___code___f_o_r_d_o_x_y_8c.html#aa9fece7b062124080e4b2976f9a8b675',1,'Interlock_Code_FORDOXY.c']]],
  ['cols_2',['COLS',['../_interlock___code___f_o_r_d_o_x_y_8c.html#aefd90f1160eaa105bc910d4d7c46b815',1,'Interlock_Code_FORDOXY.c']]],
  ['customkeypad_3',['customKeypad',['../_interlock___code___f_o_r_d_o_x_y_8c.html#a1d289fcc804ecdd92dfd8fef8f740bf0',1,'Interlock_Code_FORDOXY.c']]]
];
