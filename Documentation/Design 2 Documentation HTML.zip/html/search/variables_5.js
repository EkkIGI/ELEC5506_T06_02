var searchData=
[
  ['lastpolltime_0',['lastPollTime',['../_r_s232___luke___final__rev1___f_o_r_d_o_x_y_8c.html#a934494343251ede21bb9916ea592772b',1,'RS232_Luke_Final_rev1_FORDOXY.c']]],
  ['logactive_1',['logActive',['../_r_s232___luke___final__rev1___f_o_r_d_o_x_y_8c.html#aaea4259e66cf117a7336df426f2139f7',1,'RS232_Luke_Final_rev1_FORDOXY.c']]],
  ['loginduration_2',['loginDuration',['../_interlock___code___f_o_r_d_o_x_y_8c.html#a74c78eef89e313727e6a331418e1bd33',1,'Interlock_Code_FORDOXY.c']]]
];
