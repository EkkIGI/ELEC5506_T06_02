var searchData=
[
  ['calculatechecksum_0',['calculateChecksum',['../_interlock___code___f_o_r_d_o_x_y_8c.html#a8c2694355e28158a1d9c492fd7267a93',1,'calculateChecksum(const byte *Frame, size_t FrameLength):&#160;Interlock_Code_FORDOXY.c'],['../_r_s232___luke___final__rev1___f_o_r_d_o_x_y_8c.html#a8c2694355e28158a1d9c492fd7267a93',1,'calculateChecksum(const byte *Frame, size_t FrameLength):&#160;RS232_Luke_Final_rev1_FORDOXY.c']]]
];
