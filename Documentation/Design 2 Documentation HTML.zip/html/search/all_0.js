var searchData=
[
  ['baud_5frate_0',['baud_rate',['../namespace_s_q_m__emulator__demo__rev3___f_o_r_d_o_x_y.html#a3af0534c1b1ba228ee441fa6a0f07f7b',1,'SQM_emulator_demo_rev3_FORDOXY']]],
  ['baudrate_1',['baudRate',['../_r_s232___luke___final__rev1___f_o_r_d_o_x_y_8c.html#ad00e07811c9fbbfb0de69e741acd8ac9',1,'RS232_Luke_Final_rev1_FORDOXY.c']]]
];
