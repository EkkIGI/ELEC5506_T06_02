var indexSectionsWithContent =
{
  0: "bcdehiklmnprstuwx",
  1: "nps",
  2: "inrsu",
  3: "cdelmprstwx",
  4: "bcehklmprstu",
  5: "rs"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

