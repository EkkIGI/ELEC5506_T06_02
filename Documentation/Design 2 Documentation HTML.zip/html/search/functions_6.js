var searchData=
[
  ['readserialresponse_0',['readSerialResponse',['../_r_s232___luke___final__rev1___f_o_r_d_o_x_y_8c.html#ab3626f67db5609f421f66eb4a1fa9c58',1,'RS232_Luke_Final_rev1_FORDOXY.c']]],
  ['removewhitespace_1',['removeWhitespace',['../_interlock___code___f_o_r_d_o_x_y_8c.html#abccfc35093e7aca9a8bad9cd264d4582',1,'Interlock_Code_FORDOXY.c']]],
  ['reset_5fwatchdog_5ftimer_2',['reset_watchdog_timer',['../namespace_network___hub___f_o_r_d_o_x_y.html#a8f926d8bc6085551b58b2edd73c2fb16',1,'Network_Hub_FORDOXY']]]
];
