var searchData=
[
  ['ra8875_5fcs_0',['RA8875_CS',['../_interlock___code___f_o_r_d_o_x_y_8c.html#a9fb8294c4b98c30a3caece3d0a7d3566',1,'Interlock_Code_FORDOXY.c']]],
  ['ra8875_5fint_1',['RA8875_INT',['../_interlock___code___f_o_r_d_o_x_y_8c.html#a7a64e3f0ce565052839ed67836ed2ee8',1,'Interlock_Code_FORDOXY.c']]],
  ['ra8875_5freset_2',['RA8875_RESET',['../_interlock___code___f_o_r_d_o_x_y_8c.html#a9c9f581cd5f2978c3ea1559cd0965a27',1,'Interlock_Code_FORDOXY.c']]],
  ['rst_5fpin_3',['RST_PIN',['../_interlock___code___f_o_r_d_o_x_y_8c.html#a36932b0e869e0114f32e255f61306d6b',1,'Interlock_Code_FORDOXY.c']]]
];
